package com.loadify.repository;

import com.loadify.entity.Booking;
import com.loadify.enums.BookingStatus;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface BookingRepository extends JpaRepository<Booking, Long> {
    List<Booking> findByCustomerUserId(Long userId);
    List<Booking> findByTruckUploadedByUserId(Long providerId);
    long countByBookingStatus(BookingStatus status);
}
